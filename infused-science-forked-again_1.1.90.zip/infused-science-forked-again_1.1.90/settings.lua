data:extend({
    {
        type = "string-setting",
        name = "is-use-alt-overlay",
        setting_type = "startup",
        default_value = "Never",
        allowed_values = {"Never", "Modded only", "Always"},
        order = "a-a"  
    },
})
